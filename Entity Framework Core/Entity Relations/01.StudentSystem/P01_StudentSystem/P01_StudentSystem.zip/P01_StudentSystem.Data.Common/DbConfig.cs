﻿namespace P01_StudentSystem.Data.Common;

public class DbConfig
{
    public const string connectionString = "Server=(localdb)\\MSSQLLocalDB;Database=StudentSystem;Integrated Security = true;";
}
