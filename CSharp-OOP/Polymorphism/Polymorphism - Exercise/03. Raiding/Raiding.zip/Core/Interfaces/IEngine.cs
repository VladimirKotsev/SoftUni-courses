﻿using System;
namespace Raiding.Core
{
    public interface IEngine
    {
        void Start();
    }
}
