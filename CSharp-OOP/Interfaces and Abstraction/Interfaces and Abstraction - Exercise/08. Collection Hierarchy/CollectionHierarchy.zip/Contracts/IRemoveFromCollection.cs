﻿namespace _08._Collection_Hierarchy.Contracts
{
    public interface IRemoveFromCollection
    {
        string Remove();
    }
}
